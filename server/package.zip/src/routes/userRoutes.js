const express = require('express');
const router = express.Router();
const { verifyToken, verifyRole } = require('../middleware/auth');
const { 
  getProfile, 
  updateProfile,
  changePassword,
  getAllCustomers, 
  getAllStaff, 
  createStaff, 
  deleteStaff,
  deleteCustomer,
  addAddress,
  getAddresses,
  updateAddress,
  deleteAddress
} = require('../controllers/userController');

// User profile routes (All authenticated users)
router.get('/profile', verifyToken, getProfile);
router.put('/profile', verifyToken, updateProfile);
router.put('/change-password', verifyToken, changePassword);

// Address management
router.post('/addresses', verifyToken, addAddress);
router.get('/addresses', verifyToken, getAddresses);
router.put('/addresses/:id', verifyToken, updateAddress);
router.delete('/addresses/:id', verifyToken, deleteAddress);

// Admin and Super Admin routes
router.get('/customers', verifyToken, verifyRole(['ADMIN', 'SUPER_ADMIN']), getAllCustomers);
router.delete('/customers/:id', verifyToken, verifyRole(['ADMIN', 'SUPER_ADMIN']), deleteCustomer);
router.get('/staff', verifyToken, verifyRole(['ADMIN', 'SUPER_ADMIN']), getAllStaff);
router.post('/staff', verifyToken, verifyRole(['ADMIN', 'SUPER_ADMIN']), createStaff);
router.delete('/staff/:id', verifyToken, verifyRole(['ADMIN', 'SUPER_ADMIN']), deleteStaff);

module.exports = router;